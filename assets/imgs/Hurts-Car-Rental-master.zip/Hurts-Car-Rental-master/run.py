import app.app

app.app.main()